import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'todo_item.dart';

class TodoForm extends StatefulWidget {
  final TodoItem todoItem;

  TodoForm({this.todoItem});

  @override
  _TodoFormPageState createState() => _TodoFormPageState();
}

class _TodoFormPageState extends State<TodoForm> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _calendarController = CalendarController();

  @override
  void initState() {
    super.initState();
    if (widget.todoItem != null) {
      _titleController.text = widget.todoItem.title;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _calendarController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.todoItem != null ? 'Edit Todo' : 'Add Todo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter a title';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              Text('Due Date'),
              TableCalendar(
                calendarController: _calendarController,
                initialSelectedDay: widget.todoItem?.dueDate,
                onDaySelected: (date, _) {
                  widget.todoItem.dueDate = date;
                },
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _submitForm,
        child: Icon(Icons.check),
      ),
    );
  }

  void _submitForm() {
    if (_formKey.currentState.validate()) {
      final title = _titleController.text;
      final dueDate = _calendarController.selectedDay;
      final isComplete = widget.todoItem?.isCompleted ?? false;

      final todoItem = TodoItem(
        title: title,
        dueDate: dueDate,
        isCompleted: isComplete,
      );

      Navigator.of(context).pop(todoItem);
    }
  }
}
