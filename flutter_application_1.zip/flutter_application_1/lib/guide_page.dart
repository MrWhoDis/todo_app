import 'package:flutter/material.dart';

class GuidePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome to the Todo App!'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text(
              'This app allows you to create and manage a list of to-do items.',
              style: TextStyle(fontSize: 18),
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(height: 32),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Continue'),
          ),
        ],
      ),
    );
  }
}
