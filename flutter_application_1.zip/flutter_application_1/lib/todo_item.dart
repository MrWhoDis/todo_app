class TodoItem {
  String title;
  String items;
  String description;
  DateTime dueDate;
  bool isCompleted;

  TodoItem({
    required this.title,
    required this.items,
    required this.description,
    required this.dueDate,
    this.isCompleted = false,
  });
}
