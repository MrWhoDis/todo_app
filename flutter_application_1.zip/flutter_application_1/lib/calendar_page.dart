import 'package:table_calendar/table_calendar.dart';

class CalendarPage extends StatefulWidget {
  @override
  _CalendarPageState createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  DateTime _selectedDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CalendarCarousel(
        selectedDateTime: _selectedDate,
        onDayPressed: (DateTime date, List events) {
          setState(() {
            _selectedDate = date;
          });
        },
      ),
    );
  }
}
