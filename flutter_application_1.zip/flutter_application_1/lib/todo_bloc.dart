import 'todo_repository.dart';
import 'todo_item.dart';

class TodoBloc {
  final TodoRepository _repository = TodoRepository();

  Stream<List<TodoItem>> get todoItems =>
      Stream.fromIterable([_repository.getTodoItems()]);

  void addTodoItem(TodoItem todoItem) {
    _repository.addTodoItem(todoItem);
  }

  void updateTodoItem(int index, TodoItem todoItem) {
    _repository.updateTodoItem(index, todoItem);
  }

  void deleteTodoItem(int index) {
    _repository.deleteTodoItem(index);
  }
}
