import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

import 'todo_bloc.dart';
import 'todo_list.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Todo App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TodoBloc _bloc = TodoBloc();
  final CalendarController _calendarController = CalendarController();

  @override
  void dispose() {
    _bloc.dispose();
    _calendarController.dispose();
    super.dispose();
  }

  void _showAddTodoItemDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add Todo Item'),
          content: TodoForm(
            onSave: (title, description, dueDate) {
              _bloc.addTodoItem(
                TodoItem(
                  title: title,
                  description: description,
                  dueDate: dueDate,
                ),
              );
              Navigator.pop(context);
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter Todo App'),
      ),
      body: Column(
        children: [
          TableCalendar(
            calendarController: _calendarController,
            onDaySelected: (day, events, holidays) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TodoListPage(
                    bloc: _bloc,
                    date: day,
                  ),
                ),
              );
            },
          ),
          Expanded(
            child: TodoListPage(
              bloc: _bloc,
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddTodoItemDialog(context),
        tooltip: 'Add Todo Item',
        child: Icon(Icons.add),
      ),
    );
  }
}
