import 'package:flutter/material.dart';
import 'package:flutter_reorderable_list/flutter_reorderable_list.dart';
import 'todo_item.dart';

class TodoList extends StatefulWidget {
  final List<TodoItem> items;

  TodoList({this.items});

  @override
  _TodoListState createState() => _TodoListState();
}

class _TodoListState extends State<TodoList> {
  List<TodoItem> _items;

  @override
  void initState() {
    super.initState();
    _items = widget.items;
  }

  @override
  Widget build(BuildContext context) {
    return ReorderableList(
      onReorder: _onReorder,
      child: ListView.builder(
        itemCount: _items.length,
        itemBuilder: (context, index) {
          final item = _items[index];
          return ListTile(
            key: Key(item.id.toString()),
            title: Text(item.title),
            trailing: Checkbox(
              value: item.isComplete,
              onChanged: (value) {
                setState(() {
                  item.isComplete = value;
                });
              },
            ),
          );
        },
      ),
    );
  }

  void _onReorder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final item = _items.removeAt(oldIndex);
      _items.insert(newIndex, item);
    });
  }
}

class TodoItem {
  final int id;
  String title;
  bool isComplete;

  TodoItem({this.id, this.title, this.isComplete = false});
}
