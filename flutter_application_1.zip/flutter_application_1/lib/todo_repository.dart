import 'todo_item.dart';

class TodoRepository {
  final List<TodoItem> _todoItems = [];

  List<TodoItem> getTodoItems() {
    return _todoItems;
  }

  void addTodoItem(TodoItem todoItem) {
    _todoItems.add(todoItem);
  }

  void updateTodoItem(int index, TodoItem todoItem) {
    _todoItems[index] = todoItem;
  }

  void deleteTodoItem(int index) {
    _todoItems.removeAt(index);
  }
}
